from dataclasses import dataclass

@dataclass
class AppConfig:
    limit: int = 100
